Group 5 - Non Parametric Statistics

Authors: Nicolás Carrizosa Arias, Ángel Pellitero García & Gabriel Pons Fontoira

Contribution: We contributed equally

Exercises: Section A: 12, Section B: 9, Section C: 12

Notes: We include the .RData since both the first and second exercises take some time to compile.
       We include both the .pdf and .html compiled documents which embed code and comments.
       We include a .qmd file where the code and comments for each exercise are included.

       In the file 5.zip: We include the datasets needed (temps-7.txt, temps-7-fail.txt), 5.html and 5_files.